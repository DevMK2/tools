#include <stdio.h>

int main(int argc, const char *argv[])
{
    printf("yaho\n");
    return 0;
}
