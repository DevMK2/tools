#include <stdio.h>

int main(int argc, const char *argv[])
{
    int* a;

    printf("%d", a[3]);
    return 0;
}
